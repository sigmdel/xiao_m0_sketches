/*
  interrupts

  Test interrupts on all Seeeduino XIAO pins.

  Interrupts are used to signal the state of an input pin. The yellow LED is on whenever an input
  pin is grounded.

  Pins A5 and A7 share interrupt 9. Both cannot be used at the same time.

  The distinct interrupts attached to pins A0 and A1 share a single interrupt service routine (ISR).

*/

#include <Arduino.h>

#define PIN_5_ONLY   0       // attach an interrupt to pin A5 but not to A7
#define PIN_7_ONLY   1       // attach an interrupt to pin A7 but not to A5
#define PIN_5_AND_7  2       // attach an interrupt to pins A5 and A7 - distinct ISRs   **** Neither pin can fire the interrupt ****
#define PIN_5_7_SAME_ISR 3   // attach an interrupt to pins A5 and A7 - same ISR        **** Neither pin can fire the interrupt ****

#define EXT_INT9_PIN  PIN_5_ONLY

#define DEBOUNCE_TIME 10 // millisecond button debouncing time

volatile int activeint = -1;
volatile bool reported = true;

void SR(int pin) {
  noInterrupts();
  delay(DEBOUNCE_TIME);
  digitalWrite(LED_BUILTIN, digitalRead(pin));
    /* Exploiting the fact that the XIAO LEDS are active LOW. Here is the logic:

      if (digitalRead(BUTTON) == HIGH) {
      // If the buttonState is HIGH, the button is release so turn the LED off:
      digitalWrite(LED_BUILTIN, HIGH);
      } else {
      // If the buttonState is LOW, the button is pressed so turn LED on:
      digitalWrite(LED_BUILTIN, LOW);
      }

    With an acive HIGH LED could use digitalWrite(LED_BUILTIN, !digitalRead(BUTTON));
    */
  activeint = pin;
  reported = false;
  interrupts();
}

// used for pins 0 and 1
void button0_ISR() {
  SR(0);
}

void button2_ISR() {
  SR(2);
}
void button3_ISR() {
  SR(3);
}
void button4_ISR() {
  SR(4);
}
void button5_ISR() {
  SR(5);
}
void button6_ISR() {
  SR(6);
}
void button7_ISR() {
  SR(7);
}
void button8_ISR() {
  SR(8);
}
void button9_ISR() {
  SR(9);
}
void button10_ISR() {
  SR(10);
}

void setup() {
  // Time to upload new firmware or open the COM port (or device)
  delay(1000);
  Serial.println("Patience xiao");
  delay(7000); // time to upload new firmware

  // initialize the LED pin as an output:
  pinMode(LED_BUILTIN, OUTPUT);

  for (int pin=0; pin<11; pin++) {
    Serial.printf("DigitalPinToInterrupt(A%d) = %d, ", pin, digitalPinToInterrupt(pin));
    Serial.printf("  External interrupt: %d\n", g_APinDescription[pin].ulExtInt);
    // initialize the pin as an input and enable the internal pull up resistor:
    pinMode(pin, INPUT_PULLUP);
  }

  attachInterrupt(digitalPinToInterrupt(0), button0_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(1), button0_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(2), button2_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(3), button3_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(4), button4_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(6), button6_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(8), button8_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(9), button9_ISR, CHANGE);
  attachInterrupt(digitalPinToInterrupt(10), button10_ISR, CHANGE);

#if !(EXT_INT9_PIN == PIN_7_ONLY)
  attachInterrupt(digitalPinToInterrupt(5), button5_ISR, CHANGE);
  Serial.println("button5_ISR attached to pin 5");
#endif

#if (EXT_INT9_PIN == PIN_5_7_SAME_ISR)
    attachInterrupt(digitalPinToInterrupt(7), button5_ISR, CHANGE);
    Serial.println("button5_ISR attached to pin 7");
#elif !(EXT_INT9_PIN == PIN_5_ONLY)
    attachInterrupt(digitalPinToInterrupt(7), button7_ISR, CHANGE);
    Serial.println("button7_ISR attached to pin 7");
#endif

  Serial.println("setup() completed, starting loop(), check each pin");
}

void loop() {
 // empty right now, add code as needed.
  if ( (!reported) && (activeint >= 0) ) {
    if (activeint)
      Serial.printf("State of pin A%d changed\n", activeint);
    else
      Serial.println("State of pin A0 or A1 changed");
    reported = true;
  }
}
