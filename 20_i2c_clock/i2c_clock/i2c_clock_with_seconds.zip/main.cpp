#include <Arduino.h>
#include <Wire.h>
#include <RtcDS3231.h>

#include "src/SSD1306Ascii/src/SSD1306Ascii.h"
#include "src/SSD1306Ascii/src/SSD1306AsciiWire.h"

// -- OLED params --

// set to true if the I2C pins are above the display area
// set to false if the I2C pins are below the display area
#define PINS_AT_TOP false

// 0X3C+SA0 - 0x3C or 0x3D
#define I2C_ADDRESS 0x3C

// Define proper RST_PIN if required.
#define RST_PIN -1


// -- RTC params --

#define EVERY_SECOND 0
#define EVERY_FIVE_SECOND 1
#define REFRESH_CLOCK  EVERY_FIVE_SECOND

#define EN 0
#define FR 1
#define LANG EN


#if (LANG == EN)
  const char* dow[] = {
    "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"
  };

  const char* month[] = {
    "", "January", "February", "March", "April", "May", "June", "July",
    "August", "September", "October", "November", "December"
  };

  #define TIME_STR "%02d:%02d:%02d", now.Hour(), now.Minute(), now.Second()
  #define DATE_STR "%s %d, %d", month[now.Month()], now.Day(), now.Year()
  #define ERROR_STR  "** error **"

#elif (LANG == FR)
  const char* dow[] = {
    "Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi"
  };

  const char* month[] = {
    "", "janvier", "fevrier", "mars", "avril", "mai", "juin", "juillet",
    "aout", "septembre", "octobre", "novembre", "decembre"
  };

  #define TIME_STR "%02d:%02d:%02d", now.Hour(), now.Minute(), now.Second()
  #define DATE_STR "%d %s %d", month[now.Day(), now.Month()], now.Year()
  #define ERROR_STR  "** erreur **"

#else
  Error: LANG not defined
#endif

RtcDS3231<TwoWire> rtc(Wire);

SSD1306AsciiWire oled;

void setup() {
  delay(8000);
  // nothing written to serial monitor, start right away!

  Wire.begin();
  Wire.setClock(400000L);

  RtcDateTime compiled = RtcDateTime(__DATE__, __TIME__);

  if (!rtc.GetIsRunning()) rtc.SetIsRunning(true);

  RtcDateTime now = rtc.GetDateTime();
  if (now < compiled) rtc.SetDateTime(compiled);

  // never assume the rtc was last configured by you, so
  // just clear them to your needed state
  rtc.Enable32kHzPin(false);
  rtc.SetSquareWavePin(DS3231SquareWavePin_ModeNone);


#if RST_PIN >= 0
  oled.begin(&Adafruit128x64, I2C_ADDRESS, RST_PIN);
#else
  oled.begin(&Adafruit128x64, I2C_ADDRESS);
#endif

 #if (PINS_AT_TOP != true)
  oled.displayRemap(true);
#endif

  oled.setFont(Verdana12);
  oled.clear();
  oled.printf("displayRemap(%s)\n", (PINS_AT_TOP) ? "false" : "true");
  oled.println("Font: Verdana12");
  oled.setFont(Verdana_digits_24);

  delay(4000);
}

bool error = false;
int prevsecond = -1;

void loop () {
  RtcDateTime now = rtc.GetDateTime();
  error = (!now.IsValid() || !rtc.IsDateTimeValid());
  Serial.printf("now.isValid(): %d, rtc.IsDateTimeValid(): %d, error: %d\n", now.IsValid(), rtc.IsDateTimeValid(), error);  

#if (REFRESH_CLOCK == EVERY_SECOND)

  if (!error) {
    if (prevsecond < 0)
      prevsecond = now.Second();
    else {
      while (now.Second() == prevsecond)  {
        delay(5);
        now = rtc.GetDateTime();
      }
      prevsecond = now.Second();
    }
  }

#elif (REFRESH_CLOCK  == EVERY_FIVE_SECOND)

  if (!error) {
    // update display on 5 second interval
    while (now.Second() %5) {
      delay(5);
      now = rtc.GetDateTime();
    }
  }

#else
  ERROR: REFRESH_CLOCK is not defined
#endif

  char strBuffer[28];

  // display time
  sprintf(strBuffer, TIME_STR);
  int x = (oled.displayWidth() - oled.strWidth(strBuffer))/2;
  oled.clear();
  oled.setCol(x);
  oled.setRow(0);
  oled.print(strBuffer);

  // display day of week or error
  oled.setFont(Verdana12);
  if (error)
    strcpy(strBuffer, ERROR_STR);
  else
    strcpy(strBuffer, dow[now.DayOfWeek()]);
  oled.setCol( (oled.displayWidth() - oled.strWidth(strBuffer) )/2);
  oled.setRow(4);
  oled.println(strBuffer);

  // display date
  sprintf(strBuffer, DATE_STR);
  oled.setCol( (oled.displayWidth() - oled.strWidth(strBuffer))/2);
  oled.printf(strBuffer);

  oled.setFont(Verdana_digits_24);

#if (REFRESH_CLOCK == EVERY_SECOND)
  delay((error) ? 60000 : 600); // 1 minute on error or 0.6 seconds normally
#else
  delay((error) ? 60000 : 4000); // 1 minute on error or 4 seconds normally
#endif
}
